import boto3
import email
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication

def handler(event, context):
    s3 = boto3.client('s3')
    ses = boto3.client('ses', region_name='us-east-1')
    
    record = event['Records'][0]
    bucket = record['s3']['bucket']['name']
    key = record['s3']['object']['key']
    
    response = s3.get_object(Bucket=bucket, Key=key)
    raw_email = response['Body'].read()
    msg = email.message_from_bytes(raw_email)
    
    forward_to = os.environ['FORWARD_TO']
    from_addr = 'hello@rmzi.world'
    
    # Create forwarded message
    new_msg = MIMEMultipart()
    new_msg['Subject'] = f"[Fwd] {msg['Subject']}"
    new_msg['From'] = from_addr
    new_msg['To'] = forward_to
    new_msg['Reply-To'] = msg['From']
    
    body = f"--- Forwarded from {msg['From']} ---\n\n"
    
    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_type() == 'text/plain':
                body += part.get_payload(decode=True).decode('utf-8', errors='ignore')
    else:
        body += msg.get_payload(decode=True).decode('utf-8', errors='ignore')
    
    new_msg.attach(MIMEText(body, 'plain'))
    
    ses.send_raw_email(
        Source=from_addr,
        Destinations=[forward_to],
        RawMessage={'Data': new_msg.as_string()}
    )
    
    return {'statusCode': 200}
